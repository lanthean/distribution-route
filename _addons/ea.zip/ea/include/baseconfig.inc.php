<?php
/**
 * @Copyright (c) 2011, Bc. Martin Bortel
 * @author Bc. Martin Bortel
 * @project EA (MM2T 2011) at BUT http://vutbr.cz
 */
global $config;
$config = array(
    // je potreba nastavit dle vlastniho uloziste

    /**
     * nastaveni mysql uloziste
     */
    "dbserver" => "localhost"   //nazev databazoveho serveru
    ,"dbuser" => "root"         //uzivatelske jmeno pristupujici k databazi
    ,"dbpasswd" => ""           //pristupove heslo pro zadaneho uzivatele (viz dbuser)
    ,"dbname" => "EA"           //nazev databaze
    
    /**
     * "basepath" => "/cesta/ke/korenovemu/adresari/zdrojovych/souboru/na/serveru/"
     */
    ,"basepath" => "/Data/WWW/ea/"
    /**
     * "baseurl" => "url adresa ke korenu projektu"
     */
    ,"baseurl" => 'http://localhost/ea/'
    
);
?>
