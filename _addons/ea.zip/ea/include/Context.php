<?php

/**
 * @Copyright (c) 2011, Bc. Martin Bortel
 * @author Bc. Martin Bortel <martin.bortel(at)gmail.com>
 * @package ea
 * @project EA (MM2T 2011) at BUT http://vutbr.cz
 */

class Context extends DBObjectUI{
    protected $DBTable = "Context";
    public $SessionID;
    public $DebugOutput = array();
    public $Debug;

    public $POST;
    public $REQUEST;

    public $DontUseEA = false;
    
    public $ActivePopulationID = 1;
    public $LastPopulationFitness;
    public $Round;
    /**
     *
     * @var array
     * @uses array(
     *  "PopulationID" => Fitness
     * )
     */
    public $BestPopulationFitness = array(
        "id" => 0
        ,"value" => 0
        );
    public $PopulationFitnessDecayNum = 0;
    public $MaxPopulationFitnessDecay = 5;
    public $BestChromosomeFitness = array(
        "id" => 0
        ,"value" => 0
        );
    public $ChromosomeFitnessDecayNum = 0;
    public $MaxChromosomeFitnessDecay = 20;
    
    public $NumberOfGenes;
    public $TravelMethod;
    public $EndCondition = 10; //100 cyklu
    
    public function __construct($id = null, $id2 = null, $id3 = null) {
        $this->SessionID = $_SERVER['REMOTE_ADDR'];
        if(isset($_POST)) $this->POST = $_POST;
        if(isset($_REQUEST)) $this->REQUEST = $_REQUEST;
        
        if(!isset($this->Round)) $this->Round = 0;
        
        parent::__construct($id, $id2, $id3);
    }
}//eoclass
?>
