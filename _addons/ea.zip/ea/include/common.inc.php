<?php
/**
 * @Copyright (c) 2011, Bc. Martin Bortel
 * @author Bc. Martin Bortel
 * @project EA (MM2T 2011) at BUT http://vutbr.cz
 */

session_start();
include('baseconfig.inc.php');

//Tools
global $Tools;
require_once($config['basepath']."include/Tools.class.php");
$Tools = new Tools();

//Database
require_once($config['basepath']."resources/DbObject.php");
require_once($config['basepath']."resources/DbCollection.php");

//context
global $Context;
require_once($config['basepath']."include/Context.php");
$Context = new Context(1);


        require_once("{$config['basepath']}resources/Log.php");
        $Tools->Log = new Log();

//Engine
require_once($config['basepath']."include/Gene.class.php");
require_once($config['basepath']."include/Chromosome.class.php");
require_once($config['basepath']."include/Population.class.php");
require_once($config['basepath']."include/FitnessRelation.class.php");
require_once($config['basepath']."include/Select.class.php");
require_once($config['basepath']."include/CrossOver.class.php");

//UserInterfaces
global $Content;
require_once($config['basepath']."include/content.php");
$Content = new Content();

global $Template;
require_once($config['basepath']."include/Template.class.php");
$Template = new Template();

global $Page;
require_once($config['basepath']."include/Page.class.php");
$Page = new Page();

//Engine
global $GoogleAPI;
require_once($config['basepath']."include/UIGoogleAPI.class.php");
$GoogleAPI = new UIGoogleAPI();

global $Randomizer;
require_once($config['basepath']."include/Randomizer.class.php");
$Randomizer = new Randomizer();
  
class DataDBObject extends DbObject{
    protected $DBTable = "temp";
    public $ASSOC = true;
}
?>
