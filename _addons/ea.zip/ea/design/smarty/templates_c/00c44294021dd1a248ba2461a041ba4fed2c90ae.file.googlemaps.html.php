<?php /* Smarty version Smarty-3.0.7, created on 2011-05-24 23:09:43
         compiled from "/Data/WWW/ea/design/html/googlemaps.html" */ ?>
<?php /*%%SmartyHeaderCode:6216867074ddc1e97e13f01-51084706%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '00c44294021dd1a248ba2461a041ba4fed2c90ae' => 
    array (
      0 => '/Data/WWW/ea/design/html/googlemaps.html',
      1 => 1306271275,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '6216867074ddc1e97e13f01-51084706',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
    <script type="text/javascript">
      var directionDisplay;
      var directionsService = new google.maps.DirectionsService();
      var map;

      function initialize() {
        directionsDisplay = new google.maps.DirectionsRenderer();
        var myLatlng = new google.maps.LatLng(<?php echo $_smarty_tpl->getVariable('start')->value;?>
);
        var myOptions = {
          zoom: 13
          ,center: myLatlng
          ,mapTypeId: google.maps.MapTypeId.HYBRID
        };
        map = new google.maps.Map(document.getElementById("map_canvas"), myOptions);
        directionsDisplay.setMap(map);
        calcRoute();
      }

      function calcRoute() {
        var start = document.getElementById("start").value;
        var end = document.getElementById("end").value;
        var waypts = [];
        var checkboxArray = document.getElementById("waypoints");
        for (var i = 0; i < checkboxArray.length; i++) {
          if (checkboxArray.options[i].selected == true) {
            waypts.push({
                location:checkboxArray[i].value,
                stopover:true});
          }
        }

        var request = {
            origin: start, 
            destination: end,
            waypoints: waypts,
            optimizeWaypoints: true,
            travelMode: google.maps.DirectionsTravelMode.DRIVING
        };
        directionsService.route(request, function(response, status) {
          if (status == google.maps.DirectionsStatus.OK) {
            directionsDisplay.setDirections(response);
            var route = response.routes[0];
            var summaryPanel = document.getElementById("directions_panel");
            summaryPanel.innerHTML = "";
            // For each route, display summary information.
            for (var i = 0; i < route.legs.length; i++) {
              var routeSegment = i + 1;
              summaryPanel.innerHTML += "<b>Route Segment: " + routeSegment + "</b><br />";
              summaryPanel.innerHTML += route.legs[i].start_address + " to ";
              summaryPanel.innerHTML += route.legs[i].end_address + "<br />";
              summaryPanel.innerHTML += route.legs[i].distance.text + "<br /><br />";
            }
          }
        });
      }
    </script>
    <h1>Google JS MAP</h1>
    <input type="hidden" id="start" value="<?php echo $_smarty_tpl->getVariable('start')->value;?>
" />
    <input type="hidden" id="end" value="<?php echo $_smarty_tpl->getVariable('end')->value;?>
" />
    <select multiple id="waypoints" style="display:none;">
      <?php  $_smarty_tpl->tpl_vars['waypoint'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('waypoints')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['waypoint']->key => $_smarty_tpl->tpl_vars['waypoint']->value){
?>
        <option value="<?php echo $_smarty_tpl->tpl_vars['waypoint']->value;?>
" selected="selected"></input>
      <?php }} ?>
    </select>

    <div id="map_canvas"></div>
    
    <script type="text/javascript">
        initialize();
        calcRoute();
    </script>
