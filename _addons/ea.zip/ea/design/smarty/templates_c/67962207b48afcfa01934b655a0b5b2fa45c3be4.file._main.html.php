<?php /* Smarty version Smarty-3.0.7, created on 2011-05-25 09:48:25
         compiled from "/Data/WWW/ea/design/html/_main.html" */ ?>
<?php /*%%SmartyHeaderCode:9931037214ddcb449859287-25913822%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '67962207b48afcfa01934b655a0b5b2fa45c3be4' => 
    array (
      0 => '/Data/WWW/ea/design/html/_main.html',
      1 => 1306308797,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '9931037214ddcb449859287-25913822',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<div class="center">
    <h4>The default interface is not yet defined</h4>
    <p>
        Please try activating the <a href="<?php echo $_smarty_tpl->getVariable('config')->value['baseurl'];?>
dna/">dna</a>
        sequence or the <a href="<?php echo $_smarty_tpl->getVariable('config')->value['baseurl'];?>
cross/">crossover</a>
        or just <a href="<?php echo $_smarty_tpl->getVariable('config')->value['baseurl'];?>
run/?post=true">run</a>.
    <br />
    <br />
    <br /><a href="<?php echo $_smarty_tpl->getVariable('config')->value['baseurl'];?>
printlog/">db_log</a>&nbsp;|&nbsp;
          <a href="<?php echo $_smarty_tpl->getVariable('config')->value['baseurl'];?>
gmaps/">google maps</a>
          
    </p>
</div>
