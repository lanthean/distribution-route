<?php /* Smarty version Smarty-3.0.7, created on 2011-05-26 01:43:19
         compiled from "D:/WWW/ea/design/html/index.html" */ ?>
<?php /*%%SmartyHeaderCode:104734ddd941742ef66-09887574%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0a51e5c4436276de37428d6c8484e55d6ffd1156' => 
    array (
      0 => 'D:/WWW/ea/design/html/index.html',
      1 => 1306318256,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '104734ddd941742ef66-09887574',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <?php echo $_smarty_tpl->getVariable('headcontent')->value;?>


</head>
    <body><?php echo $_smarty_tpl->getVariable('bodyScripts')->value;?>
<?php echo $_smarty_tpl->getVariable('debug')->value;?>

        <h1><?php echo $_smarty_tpl->getVariable('Title')->value;?>
</h1>
        <?php echo $_smarty_tpl->getVariable('body')->value;?>

        <div class="addons"><?php echo $_smarty_tpl->getVariable('addons')->value;?>
</div>
    </body>
</html>