<?php /* Smarty version Smarty-3.0.7, created on 2011-05-26 11:28:31
         compiled from "/Data/WWW/ea/design/html/_form.html" */ ?>
<?php /*%%SmartyHeaderCode:584595694dde1d3fa3eec9-19405584%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b8abf4beccaa9b48e1aa0c61367cb4844bdfd501' => 
    array (
      0 => '/Data/WWW/ea/design/html/_form.html',
      1 => 1306402111,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '584595694dde1d3fa3eec9-19405584',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<div class="center" style="margin-top: 25px;">
    <h1>Optimalizace obchodní trasy</h1>
    <h3>zadejte jednotlivé body překládky</h3>
    <p>Adresy vkládejte ve tvaru např: Gorkého 20, 60200 Brno,<br />nebo ve formátu GPS souřadnic např: 49°11'59.284"N, 16°35'50.115"E</p>
    <form action="<?php echo $_smarty_tpl->getVariable('config')->value['baseurl'];?>
<?php echo $_smarty_tpl->getVariable('script')->value;?>
/" method="post">
        <table>
            <tbody>
                <?php  $_smarty_tpl->tpl_vars['text'] = new Smarty_Variable;
 $_smarty_tpl->tpl_vars['name'] = new Smarty_Variable;
 $_from = $_smarty_tpl->getVariable('Rows')->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
if ($_smarty_tpl->_count($_from) > 0){
    foreach ($_from as $_smarty_tpl->tpl_vars['text']->key => $_smarty_tpl->tpl_vars['text']->value){
 $_smarty_tpl->tpl_vars['name']->value = $_smarty_tpl->tpl_vars['text']->key;
?>
                <tr><td class="left_lb"><?php echo $_smarty_tpl->tpl_vars['text']->value;?>
 adresa:</td>
                    <td><input id="<?php echo $_smarty_tpl->tpl_vars['name']->value;?>
" type="text" name="address[<?php echo $_smarty_tpl->tpl_vars['name']->value;?>
]" />
                        <?php if (isset($_smarty_tpl->getVariable('error_msg',null,true,false)->value[$_smarty_tpl->tpl_vars['name']->value])){?><br /><span class="error"><?php echo $_smarty_tpl->getVariable('error_msg')->value[$_smarty_tpl->tpl_vars['name']->value];?>
</span><?php }?></td></tr>
                <?php }} ?>
                <tr><td colspan="2" class="center">
                        <input id="radio1" type="radio" name="TravelMethod" value="distance" checked="true" />
                            <label for="radio1">Vzdálenost</label>
                        &nbsp;&nbsp;&nbsp;
                        <input id="radio2" type="radio" name="TravelMethod" value="duration"/>
                            <label for="radio2">Čas</label>
                    </td></tr>
                <tr><td class="left_lb">Velikost populace:</td>
                    <td><input id="PopulationSize" class="short" type="text" name="PopulationSize" value="10" />
                        <?php if (isset($_smarty_tpl->getVariable('PopulationSize_err',null,true,false)->value)){?><br /><span class="error"><?php echo $_smarty_tpl->getVariable('PopulationSize_err')->value;?>
</span><?php }?></td></tr>
                <tr><td colspan="2">&nbsp;</td></tr>
                <tr><td class="right" colspan="2"><input type="submit" name="_form" value="Odeslat" /></td></tr>
            </tbody>
        </table>        
    </form>
</div>